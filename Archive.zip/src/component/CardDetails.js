import React from 'react';
import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import CardData from '../CardData';

const CardDetails = () => {
  const [data, setData] = useState(CardData);

  return (
    <View>
      {data.map((item, i) => {
        return (
          <React.Fragment>
            <View
              style={{
                flexDirection: 'row',
                padding: 10,
                borderBottomWidth: 1,
                borderBottomColor: '#ddd',
                backgroundColor:
                  item.score < 80 || item.score > 85 ? 'red' : 'green',
              }}>
              <View style={{marginTop: 15, flexDirection: 'row'}}>
                <Text
                  style={{
                    marginLeft: 20,
                    width: '80%',
                    color: '#000',
                    fontWeight: '600',
                  }}>
                  {name}
                </Text>
                <Text
                  style={{
                    textAlign: 'right',
                    fontWeight: '700',
                    color: '#000',
                  }}>
                  {id}
                </Text>
              </View>
            </View>
          </React.Fragment>
        );
      })}
    </View>
  );
};

export default CardDetails;

const styles = StyleSheet.create({});
