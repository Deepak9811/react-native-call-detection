export const Item = [
  {
    id: 1,
    name: 'Boba Fett',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Boba-Fett-icon.png',
  },
  {
    id: 2,
    name: 'C3PO',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/C3PO-icon.png',
  },
  {
    id: 3,
    name: 'Chewbacca',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Chewbacca-icon.png',
  },
  {
    id: 4,
    name: 'Darth Vader',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Darth-Vader-icon.png',
  },
  {
    id: 5,
    name: 'Emperor',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Emperor-icon.png',
  },
  {
    id: 6,
    name: 'Han Solo',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Han-Solo-icon.png',
  },
  {
    id: 7,
    name: 'Princess Leia',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Leia-icon.png',
  },
  {
    id: 8,
    name: 'Luke Skywalker',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Luke-Skywalker-icon.png',
  },
  {
    id: 9,
    name: 'Obi Wan Kenobi',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Obi-Wan-icon.png',
  },
  {
    id: 10,
    name: 'R2D2',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/R2D2-icon.png',
  },
  {
    id: 11,
    name: 'Stormtrooper',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Stormtrooper-icon.png',
  },
  {
    id: 12,
    name: 'Yoda',
    icon: 'http://icons.iconarchive.com/icons/creativeflip/starwars-longshadow-flat/128/Yoda-icon.png',
  },
];
